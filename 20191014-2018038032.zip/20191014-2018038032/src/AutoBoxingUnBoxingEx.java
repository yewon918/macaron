//6-6
public class AutoBoxingUnBoxingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		Integer intObject = n; //auto boxing
		//Integer intObject = Integer.value(10);
		System.out.println("intObject= " + intObject);
		
		int m = intObject + 10; //auto unboxing
		//int m = intObject.intValue()+10;
		System.out.println("m = " + m);
	
	}

}
