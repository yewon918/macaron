package app;

import base.Shape;
import derived.Circle;
public class GraphicEditor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape shape = new Circle();
		shape.draw();
	}

}
