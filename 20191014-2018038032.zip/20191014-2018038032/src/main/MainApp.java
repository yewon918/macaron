package main;
import etc.Calc;

public class MainApp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calc c = new Calc(10,20);
		System.out.println(c.sum());
	}
}
