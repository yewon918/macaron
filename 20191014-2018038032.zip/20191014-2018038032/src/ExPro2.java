//2

class Circle{
	int x, y,z;
	public Circle(int a, int b, int c) {
		this.x =a; this.y=b; this.z=c;
	}
	public boolean equals(Object obj) {
		Circle c = (Circle)obj;
		if(this.x==x && this.y==y) {
			return true;
		}
		else return false;
	}
	public String toString() {
		return "Circle ("+x+","+y+")  ������"+z;
		
	}
}

public class ExPro2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle a = new Circle(2,3,5);
		Circle b = new Circle(2,3,30);
		System.out.println("�� a : " + a);
		System.out.println("�� b :" + b);
		if(a.equals(b)) 
			System.out.println("���� ��");
		else
			System.out.println("���� �ٸ� ��");
	}

}
