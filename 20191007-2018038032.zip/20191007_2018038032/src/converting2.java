
import java.util.Scanner;
abstract class Converter {
	abstract protected double convert(double src);
	abstract protected String getsrcstring();
	abstract protected String getDeststring();
	protected double ratio;
	public void run() {
		Scanner scanner = new Scanner(System.in);
		System.out.println(getsrcstring()+"��"+getDeststring()+"�� �ٲߴϴ�.");
		System.out.println(getsrcstring()+"�� �Է��ϼ���>>");
		double val = scanner.nextDouble();
		double res = convert(val);
		System.out.println("��ȯ���: "+res+getDeststring()+"�Դϴ�.");
		scanner.close();
	}
}

class Won2Dollar extends Converter {
	public Won2Dollar(double ratio) {
		this.ratio=ratio;
	}
	protected double convert(double src) {
		return src/ratio;
	}
	protected String getsrcstring() {return "��";}
	protected String getDestString() {return "�޷�";}
}
class Km2Mile extends Converter {
	public Km2Mile(double ratio) {this.ratio=ratio;}
	protected double convert(double src) {return src/ratio;}
	protected String getsrcstring() {return "Km";}
	protected String getDeststring() {return "mile";}
} 
public class converting2 {
	
	public static void main(String args[]) {
		Km2Mile toMile = new Km2Mile(1.6);
		toMile.run();
	}
}


