
class TV {
	private int size;
	public TV(int size) {this.size = size;}
	protected int getsize() {return size;}
}
class ColorTV extends TV {
	
	private int resolution;
	ColorTV(int size, int resolution) {
		super(size);
		this.resolution=resolution;
	}

	public void printProperty() {		
		System.out.println(getsize()+"��ġ"+resolution+"�÷�");
	}
}

public class ColorTVact {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ColorTV myTV = new ColorTV(32,1024);
		myTV.printProperty();

	}
	
}
