class Point5 {
   private int x, y;
   public Point5(int x, int y) { this.x = x; this.y = y; }
   public int getX() { return x; }
   public int getY() { return y; }
   protected void move(int x, int y) { this.x =x; this.y = y; }
}

class ColorPoint5 extends Point5 {
	   private String color;
	   public ColorPoint5(int x, int y, String color) {
	      super(x, y);
	      this.color = color;
	   }
	   public void setXY(int x, int y){
	         move(x, y);
	   }
	   public void setColor(String color){
	      this.color = color;
	   }
	   public String toString() {
	      String tmp = color+"����"+" ("+getX()+","+getY()+")�� ��";
	      return tmp;
	   }
}

class ColorPoint6 extends Point5{
	   private String color;
	   public ColorPoint6() {
	      super(0, 0);
	      this.color = "BLACK";
	   }
	   public ColorPoint6(int x, int y) {
	      super(x, y);
	      this.color = "BLACK";
	   }
	   public void setXY5(int x, int y) {
	      move(x, y);
	   }
	   public void setColor5(String color) {
	      this.color = color;
	   }
	   public String toString() {
	      String tmp = color+"���� ("+getX()+","+getY()+") ��";
	      return tmp;
	   }
}

public static void main(String[] args) {
	   ColorPoint6 zeroPoint = new ColorPoint6(); // (0,0) ��ġ�� BLACK �� ��
	   System.out.println(zeroPoint.toString() + "�Դϴ�.");
	   ColorPoint6 cp = new ColorPoint6(10, 10); // (10,10) ��ġ�� BLACK �� ��
	   cp.setXY5(5,5);
	   cp.setColor5("RED");
	   System.out.println(cp.toString()+"�Դϴ�.");
}