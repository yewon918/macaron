//5-4 18�迹��

class Person{}
class Student extends Person{}
class Researcher extends Person{}
class Professor extends Researcher{}

public class InstanceOfEx {
	static void print(Person p) {
		if(p instanceof Person) //person Ÿ��
			System.out.print("Person ");
		if(p instanceof Student) //Student Ÿ��
			System.out.print("Student ");
		if(p instanceof Researcher) //researcher Ÿ��
			System.out.print("Researcher ");
		if(p instanceof Professor) //professor Ÿ��
			System.out.print("Professor ");
		System.out.println();
	}
	public static void main(String[] args) {	//���
		// TODO Auto-generated method stub
		System.out.print("new Student()->\t");
		print(new Student());
		System.out.print("new Researcher() -> \t");
		print(new Researcher());
		System.out.print("new Professor -> \t");
		print(new Professor());
	}

}
