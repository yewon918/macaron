/////3��
import java.util.Scanner;
abstract class Converter {
	abstract protected double convert(double src);
	abstract protected String getsrcstring();
	abstract protected String getDeststring();
	protected double ratio;
	public void run() {
		Scanner scanner = new Scanner(System.in);
		System.out.println(getsrcstring()+"��"+getDeststring()+"�� �ٲߴϴ�.");
		System.out.println(getsrcstring()+"�� �Է��ϼ���>>");
		double val = scanner.nextDouble();
		double res = convert(val);
		System.out.println("��ȯ���: "+res+getDeststring()+"�Դϴ�.");
		scanner.close();
	}
}
///////3��
class Won2Dollar extends Converter {
	public Won2Dollar(double ratio) {
		this.ratio=ratio;
	}
	protected double convert(double src) {
		return src/ratio;
	}
	protected String getsrcstring() {return "��";}
	protected String getDestString() {return "�޷�";}
}
 
public class converting {
	/////////3��
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Won2Dollar toDollar = new Won2Dollar(1200);
		toDollar.run();
	}

	
}


