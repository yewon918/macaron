//////5��
class Point_ {
	private int x,y;
	public Point_(int x, int y) {this.x=x; this.y=y;}
	public int getX() {return x;}
	public int getY() {return y;}
	protected void move(int x, int y) {this.x=x; this.y=y;}
}

class ColorPoint_ extends Point_ {
	private String color;
	  public ColorPoint_(int x, int y, String color) {
	      super(x, y);
	      this.color = color;
	   }
	   public void setXY(int x, int y){
	         move(x, y);
	   }
	   public void setColor(String color){
	      this.color = color;
	   }
	   public String toString() {
	      String tmp = color+"����"+" ("+getX()+","+getY()+")�� ��";
	      return tmp;
	   }	
}

class ColorPoint2 extends Point_ {
	private String color;
	public ColorPoint2() {
		super(0,0);
		this.color="BLACK";
	}
	public ColorPoint2(int x, int y) {
	      super(x, y);
	      this.color = "BLACK";
	   }
	   public void setXY(int x, int y) {
	      move(x, y);
	   }
	   public void setColor(String color) {
	      this.color = color;
	   }
	   public String toString() {
	      String tmp = color+"���� ("+getX()+","+getY()+") ��";
	      return tmp;
	 
	
} 
	   
public class colorit {
	public void main(String[] args) {
		// TODO Auto-generated method stub
		ColorPoint2 cp = new ColorPoint2(5,5,"Yellow");
		cp.setXY(10,20);
		cp.setColor("RED");
		String str=cp.toString();
		System.out.println(str+"�Դϴ�.");

	}
	
	}
}

